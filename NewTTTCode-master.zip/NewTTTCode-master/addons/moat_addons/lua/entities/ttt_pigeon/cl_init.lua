include( "shared.lua" )



ENT.PrintName = "Homing Pigeon"

ENT.Icon = "VGUI/ttt/icon_homingpigeon"

