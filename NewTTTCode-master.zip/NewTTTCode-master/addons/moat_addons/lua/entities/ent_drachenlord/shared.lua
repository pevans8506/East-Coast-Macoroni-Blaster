ENT.Type = "anim"
ENT.Base = "base_anim"
 
ENT.PrintName = "Drachenlord"
 
ENT.Spawnable = false
ENT.AdminOnly = false