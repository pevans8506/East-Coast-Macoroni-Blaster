ENT.Type = "ai"
ENT.Base = "base_gmodentity"
ENT.PrintName = "DRAGON"

ENT.Spawnable = false
ENT.AdminSpawnable = false

ENT.AutomaticFrameAdvance = true