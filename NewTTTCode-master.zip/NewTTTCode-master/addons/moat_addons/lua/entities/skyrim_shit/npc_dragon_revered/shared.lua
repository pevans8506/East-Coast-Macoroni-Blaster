ENT.Base = "npc_dragon"
ENT.Type = "ai"

ENT.PrintName = "Revered Dragon"
ENT.Category = "Skyrim"
// ENT.NPCID = ""

if(CLIENT) then
	language.Add("npc_dragon_revered","Revered Dragon")
end

