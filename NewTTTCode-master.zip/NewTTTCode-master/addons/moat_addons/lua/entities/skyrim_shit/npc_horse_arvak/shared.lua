ENT.Base = "npc_horse"
ENT.Type = "ai"

if(CLIENT) then
	language.Add("npc_horse_arvak","Arvak")
end