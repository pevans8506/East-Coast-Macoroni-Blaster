ENT.Base = "npc_creature_base"
ENT.Type = "ai"

ENT.PrintName = "Dwarven Spider"
ENT.Category = "Skyrim"
//ENT.NPCID = ""

if(CLIENT) then
	language.Add("npc_dwarven_spider","Dwarven Spider")
end

