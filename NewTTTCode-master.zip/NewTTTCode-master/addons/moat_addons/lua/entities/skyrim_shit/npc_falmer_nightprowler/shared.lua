ENT.Base = "npc_falmer"
ENT.Type = "ai"

ENT.PrintName = "Falmer Nightprowler"
ENT.Category = "Skyrim"

if(CLIENT) then
	language.Add("npc_falmer_nightprowler","Falmer Nightprowler")
end