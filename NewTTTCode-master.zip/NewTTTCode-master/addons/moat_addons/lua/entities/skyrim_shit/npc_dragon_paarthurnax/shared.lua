ENT.Base = "npc_dragon"
ENT.Type = "ai"

ENT.PrintName = "Paarthurnax"
ENT.Category = "Skyrim"
// ENT.NPCID = ""

if(CLIENT) then
	language.Add("npc_dragon_paarthurnax","Paarthurnax")
end

