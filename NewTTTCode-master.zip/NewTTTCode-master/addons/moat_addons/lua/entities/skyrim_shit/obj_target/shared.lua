
ENT.Type 			= "anim"
ENT.Base 			= "base_entity"
ENT.PrintName		= "Target Object"
ENT.Author			= "Silverlan"

ENT.Spawnable			= false
ENT.AdminSpawnable		= false
