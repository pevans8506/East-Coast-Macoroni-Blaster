include('shared.lua')

function ENT:Draw()
end