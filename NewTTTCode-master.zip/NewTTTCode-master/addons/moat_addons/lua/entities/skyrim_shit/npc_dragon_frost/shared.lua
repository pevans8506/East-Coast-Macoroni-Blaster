ENT.Base = "npc_dragon"
ENT.Type = "ai"

ENT.PrintName = "Frost Dragon"
ENT.Category = "Skyrim"
ENT.NPCID = "000E640"

if(CLIENT) then
	language.Add("npc_dragon_frost","Frost Dragon")
end

