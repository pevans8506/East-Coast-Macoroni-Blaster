ENT.Base = "npc_falmer"
ENT.Type = "ai"

ENT.PrintName = "Falmer Shadowmaster"
ENT.Category = "Skyrim"

if(CLIENT) then
	language.Add("npc_falmer_shadowmaster","Falmer Shadowmaster")
end