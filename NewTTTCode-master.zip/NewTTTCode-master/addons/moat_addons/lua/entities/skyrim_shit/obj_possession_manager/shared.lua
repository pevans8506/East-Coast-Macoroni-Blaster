
ENT.Type 			= "anim"
ENT.Base 			= "base_entity"
ENT.PrintName		= "Possession Manager"
ENT.Author			= "Silverlan"

ENT.Spawnable			= false
ENT.AdminSpawnable		= false
