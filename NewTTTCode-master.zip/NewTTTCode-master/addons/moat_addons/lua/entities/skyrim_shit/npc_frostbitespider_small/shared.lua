ENT.Base = "npc_frostbitespider"
ENT.Type = "ai"

ENT.PrintName = "Small Frostbite Spider"
ENT.Category = "Skyrim"
//ENT.NPCID = "000G4KL5"

if(CLIENT) then
	language.Add("npc_frostbitespider_small","Small Frostbite Spider")
end

