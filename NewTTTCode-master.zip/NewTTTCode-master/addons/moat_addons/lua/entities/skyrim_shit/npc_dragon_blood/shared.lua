ENT.Base = "npc_dragon"
ENT.Type = "ai"

ENT.PrintName = "Blood Dragon"
ENT.Category = "Skyrim"
ENT.NPCID = "0006MU4"

if(CLIENT) then
	language.Add("npc_dragon_forest","Blood Dragon")
end

