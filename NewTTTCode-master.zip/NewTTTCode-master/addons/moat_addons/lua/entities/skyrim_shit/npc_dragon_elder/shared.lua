ENT.Base = "npc_dragon"
ENT.Type = "ai"

ENT.PrintName = "Elder Dragon"
ENT.Category = "Skyrim"
ENT.NPCID = "000R3UW"

if(CLIENT) then
	language.Add("npc_dragon_elder","Elder Dragon")
end

