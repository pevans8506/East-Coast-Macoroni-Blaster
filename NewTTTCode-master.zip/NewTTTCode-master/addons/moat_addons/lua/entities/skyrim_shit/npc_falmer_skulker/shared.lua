ENT.Base = "npc_falmer"
ENT.Type = "ai"

ENT.PrintName = "Falmer Skulker"
ENT.Category = "Skyrim"

if(CLIENT) then
	language.Add("npc_falmer_skulker","Falmer Skulker")
end