ENT.Base = "npc_dragon"
ENT.Type = "ai"

ENT.PrintName = "Ancient Dragon"
ENT.Category = "Skyrim"
ENT.NPCID = "00066XN"

if(CLIENT) then
	language.Add("npc_dragon_ancient","Ancient Dragon")
end

