ENT.Base = "npc_creature_base"
ENT.Type = "ai"

ENT.PrintName = "Mudcrab"
ENT.Category = "Skyrim"
ENT.NPCID = "000SLRL3"

if(CLIENT) then
	language.Add("npc_mudcrab","Mudcrab")
end

