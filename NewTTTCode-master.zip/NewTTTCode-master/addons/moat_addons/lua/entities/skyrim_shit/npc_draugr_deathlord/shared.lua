ENT.Base = "npc_draugr"
ENT.Type = "ai"

ENT.PrintName = "Draugr Deathlord"
ENT.Category = "Skyrim"

if(CLIENT) then
	language.Add("npc_draugr_deathlord","Draugr Deathlord")
end