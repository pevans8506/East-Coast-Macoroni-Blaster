ENT.Base = "npc_creature_base"
ENT.Type = "ai"

ENT.PrintName = "Chaurus"
ENT.Category = "Skyrim"
ENT.NPCID = "0005PQS3"

if(CLIENT) then
	language.Add("npc_chaurus_flyer","Chaurus Hunter")
end

