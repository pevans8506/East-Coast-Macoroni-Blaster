ENT.Base = "npc_dragon"
ENT.Type = "ai"

ENT.PrintName = "Odahviing"
ENT.Category = "Skyrim"
ENT.NPCID = "000DBR6"

if(CLIENT) then
	language.Add("npc_dragon_odahviing","Odahviing")
end

