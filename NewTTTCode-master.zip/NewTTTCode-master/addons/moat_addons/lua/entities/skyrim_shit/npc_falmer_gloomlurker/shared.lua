ENT.Base = "npc_falmer"
ENT.Type = "ai"

ENT.PrintName = "Falmer Gloomlurker"
ENT.Category = "Skyrim"

if(CLIENT) then
	language.Add("npc_falmer_gloomlurker","Falmer Gloomlurker")
end