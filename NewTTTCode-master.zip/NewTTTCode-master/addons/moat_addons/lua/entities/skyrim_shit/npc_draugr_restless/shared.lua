ENT.Base = "npc_draugr"
ENT.Type = "ai"

ENT.PrintName = "Restless Draugr"
ENT.Category = "Skyrim"

if(CLIENT) then
	language.Add("npc_draugr_restless","Restless Draugr")
end