ENT.Base = "npc_draugr"
ENT.Type = "ai"

ENT.PrintName = "Draugr Scourge"
ENT.Category = "Skyrim"

if(CLIENT) then
	language.Add("npc_draugr_scourge","Draugr Scourge")
end