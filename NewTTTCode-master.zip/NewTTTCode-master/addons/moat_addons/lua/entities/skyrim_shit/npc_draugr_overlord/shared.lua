ENT.Base = "npc_draugr"
ENT.Type = "ai"

ENT.PrintName = "Draugr Overlord"
ENT.Category = "Skyrim"

if(CLIENT) then
	language.Add("npc_draugr_overlord","Draugr Overlord")
end