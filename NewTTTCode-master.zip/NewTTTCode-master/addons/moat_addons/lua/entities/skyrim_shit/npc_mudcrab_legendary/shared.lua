ENT.Base = "npc_mudcrab"
ENT.Type = "ai"

ENT.PrintName = "Legendary Mudcrab"
ENT.NPCID = "000DOT5U"

if(CLIENT) then
	language.Add("npc_mudcrab_legendary","Legendary Mudcrab")
end

