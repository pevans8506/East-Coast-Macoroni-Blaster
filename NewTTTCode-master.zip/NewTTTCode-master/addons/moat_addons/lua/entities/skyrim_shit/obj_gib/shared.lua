
ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= "Gib"
ENT.Author			= "Silverlan"

ENT.Spawnable			= false
ENT.AdminSpawnable		= false
