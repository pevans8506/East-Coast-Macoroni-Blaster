ENT.Base = "npc_dragon"
ENT.Type = "ai"

ENT.PrintName = "Skeletal Dragon"
ENT.Category = "Skyrim"
ENT.NPCID = "000NROW"

if(CLIENT) then
	language.Add("npc_dragon_skeleton","Skeletal Dragon")
end

