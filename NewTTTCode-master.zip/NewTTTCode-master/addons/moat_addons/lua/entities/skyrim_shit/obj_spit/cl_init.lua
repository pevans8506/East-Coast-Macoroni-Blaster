include('shared.lua')

language.Add("obj_sporeplant_spit", "Spore Plant")
function ENT:Draw()
end

function ENT:Initialize()
end
 
function ENT:OnRemove()
end
 