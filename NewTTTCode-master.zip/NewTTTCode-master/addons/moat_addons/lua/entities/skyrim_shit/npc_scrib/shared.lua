ENT.Base = "npc_creature_base"
ENT.Type = "ai"

ENT.PrintName = "Ash Hopper"
ENT.Category = "Skyrim"

if(CLIENT) then
	language.Add("npc_scrib","Ash Hopper")
end

