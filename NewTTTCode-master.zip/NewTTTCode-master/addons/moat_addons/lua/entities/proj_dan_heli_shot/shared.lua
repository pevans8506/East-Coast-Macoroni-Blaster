 ENT.Type = "anim"
 ENT.PrintName		= "Bolter Shot"  
 ENT.Author			= ""  
 ENT.Contact			= ""  
 ENT.Purpose			= ""  
 ENT.Instructions	= ""  
 
ENT.Spawnable			= false
ENT.AdminSpawnable		= false
ENT.exploding			= false

