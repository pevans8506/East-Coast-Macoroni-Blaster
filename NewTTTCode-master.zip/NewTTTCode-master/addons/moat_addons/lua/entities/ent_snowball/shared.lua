ENT.Type			= "anim"
ENT.Base			= "base_entity"
ENT.PrintName		= "snowball_entity"
ENT.Author			= "Blackjackit"
ENT.Purpose 		= "snowball_entity"
ENT.Category		= "Snowballs"

ENT.Spawnable			= false
ENT.AdminSpawnable		= false 
