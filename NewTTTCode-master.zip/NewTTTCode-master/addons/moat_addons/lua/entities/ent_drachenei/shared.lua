ENT.Type = "anim"
ENT.Base = "base_anim"
 
ENT.PrintName = "Drachenei"
 
ENT.Spawnable = false
ENT.AdminOnly = false