
ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= "Traitor Sentry"
ENT.Author			= "Tomasas"

