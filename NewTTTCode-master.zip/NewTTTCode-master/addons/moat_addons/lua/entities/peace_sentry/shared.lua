
ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= "Peace Sentry"
ENT.Author			= "Tomasas"

