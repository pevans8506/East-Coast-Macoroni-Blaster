ENT.Type = "anim"
ENT.Base = "base_anim"
 
ENT.PrintName = "Drachenbullet"
 
ENT.Spawnable = false
ENT.AdminOnly = false