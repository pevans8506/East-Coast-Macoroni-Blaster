ENT.Type = "anim"  
ENT.Base = "base_gmodentity"     
ENT.PrintName = "FIREBALL"
 
ENT.Spawnable = false
ENT.AdminSpawnable = false

ENT.exploding = false