//info
ENT.Type				= "anim";
ENT.Base				= "base_anim";
ENT.PrintName			= "Banana entity";
ENT.Author				= "GHX,Schnul44";
ENT.Purpose 			= "Sweeeeet Banana";
ENT.Category			= "GHXX_Schnul44_weapons";

//spawnable
ENT.Spawnable			= false;
ENT.AdminSpawnable		= false;