include('shared.lua')

ENT.PrintName = "Mine Turtle"
