ENT.Type			= "anim"
ENT.Spawnable		= false
ENT.AdminSpawnable  = false
ENT.Projectile		= true

ENT.PrintName		= "Chicken Egg"
ENT.Author			= "Created by Phoenixf129 and reworked by BocciardoLight"
ENT.Contact    		= ""
ENT.Purpose 		= "Egg"
ENT.Instructions 	= "EGG!"
ENT.Icon 			= "vgui/ttt/icon_chicken.png"