ENT.Type			= "anim"
ENT.Spawnable		= false
ENT.AdminSpawnable  = true

ENT.PrintName		= "Chicken"
ENT.Author			= "Created by Phoenixf129 and reworked by BocciardoLight"
ENT.Contact    		= ""
ENT.Purpose 		= "Chicken"
ENT.Instructions 	= "Chicken"
ENT.Projectile		= true
ENT.Icon			= "vgui/ttt/icon_chicken.png"
ENT.CanPickup		= true
ENT.AllowPropspec 	= false
ENT.IsPoisoned 		= false