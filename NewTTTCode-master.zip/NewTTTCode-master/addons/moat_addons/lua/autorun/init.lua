moat = moat or {}

if (moat and next(moat) == nil) then
	include "system/app/core/init.lua"
end

return moat