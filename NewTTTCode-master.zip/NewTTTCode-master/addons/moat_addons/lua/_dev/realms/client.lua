-- dev realms for code testing
-- called after realm config is loaded

TEST_VAR = true